public interface IConfigFile
{
    
}
