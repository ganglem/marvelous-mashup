public enum ConfigType
{
    CharacterConfig, ScenarioConfig, MatchConfig
}