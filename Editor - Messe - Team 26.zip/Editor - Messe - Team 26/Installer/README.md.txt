# Disclaimer

- The Editor only runs on Windows!


# How to use the installer

1. Open the "Team26EditorSetup.exe" installer.
2. Grant administrator permissions.
3. Select the directory you want to install the application to. Then click "Next".
4. Choose whether to create a desktop shortcut or not. Then click "Next".
5. Check the destination location and click "Back" to change the location or click "Install" to start the installation process.
6. When the installation is completed, click "Finish".